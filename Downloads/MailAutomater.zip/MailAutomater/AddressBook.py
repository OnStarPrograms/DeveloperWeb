import openpyxl

def GetData(Required, Data):
    wb = openpyxl.load_workbook('AddressData.xlsx')
    WhiteLis = wb['Sheet1']
    matches = ""
    match Required.lower():
        case "name":
            col = 2
        case "lastname":
            col = 3
        case "city":
            col = 5
        case "state":
            col = 6
        case "zip":
            col = 7
    for i in range(1, WhiteLis.max_row+1):
        if (WhiteLis.cell(row = i, column = col).value == Data.lower()):
            for j in range(2, 8):
                matches+=WhiteLis.cell(row = i, column = j).value+" "
            matches+="\n"
    return matches

def insert(Str):
    wb = openpyxl.load_workbook('AddressData.xlsx')
    AddressData = wb['Sheet1']
    nStr = Str.split(":")
    newcell = AddressData.max_row+1
    for i,j in enumerate(nStr):
        i+=2
        AddressData.cell(row = newcell, column = i).value = j.lower()
    wb.save('AddressData.xlsx')
    return Str
