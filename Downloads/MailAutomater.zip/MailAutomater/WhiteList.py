import openpyxl

def Allow(Str, Super, Phone):
    wb = openpyxl.load_workbook('WhiteList.xlsx')
    WhiteList = wb['Sheet1']
    col = 2
    if (Super):
        WhiteList = wb['Sheet2']
        if (Phone):
            col = 5
    newcell = WhiteList.max_row+1
    WhiteList.cell(row = newcell, column = col).value = Str
    wb.save('WhiteList.xlsx')
    return True

def verAllow(Str, Super):
    wb = openpyxl.load_workbook('WhiteList.xlsx')
    WhiteList = wb['Sheet1']
    if (Super):
        WhiteList = wb['Sheet2']
    for i in range(1, WhiteList.max_row+1):
        if (WhiteList.cell(row = i, column = 2).value == Str):
            return True
    return False

def getAdminList(Phone):
    wb = openpyxl.load_workbook('WhiteList.xlsx')
    WhiteList = wb['Sheet2']
    ListoAdmin = []
    if (Phone):
        for i in range(1, WhiteList.max_row+1):
            ListoAdmin.append(WhiteList.cell(row = i, column = 5).value)
    else:
        for i in range(1, WhiteList.max_row+1):
            ListoAdmin.append(WhiteList.cell(row = i, column = 2).value)
    return ListoAdmin




# if __name__ == "__main__":
#     if(Allow('aidenthomas711@gmail.com', True)):
#         print(verAllow('aidenthomas711@gmail.com', True))
#         print(verAllow('OnStarPrograms@gmail.com', True))
#     if(Allow('aidenthomas711@gmail.com', False)):
#         print(verAllow('aidenthomas711@gmail.com', False))
#         print(verAllow('OnStarPrograms@gmail.com', False))