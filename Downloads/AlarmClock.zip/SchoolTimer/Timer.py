from tkinter import *
import tkinter as tk
from tkinter import filedialog
import os 

def smain(dir_path):
        def WeekDayUpDate():
            f = open("%sWeekday.txt" % (dir_path),"r")
            DiffTime = f.read()
            f.close()
            WeekDayUpDateShell = Tk()
            window_width = 345
            window_height = 305
            # get the screen dimension
            screen_width = WeekDayUpDateShell.winfo_screenwidth()
            screen_height = WeekDayUpDateShell.winfo_screenheight()
            # find the center point
            center_x = int(screen_width/2 - window_width / 2)
            center_y = int(screen_height/2 - window_height / 2)
            WeekDayUpDateShell.geometry(f'{window_width}x{window_height}+{center_x}+{center_y}')
            def input():
                NewInsert = inputtxt.get("1.0", "end")
                if (NewInsert[0] != "T"):
                    f = open("%sWeekday.txt" % (dir_path),"a")
                    f.write(NewInsert)
                    f.close()
                    WeekDayUpDateShell.destroy()
                    WeekDayUpDate()
            # def SetUp():
            #     filePath = filedialog.askopenfilename()
            #     f = open ("%sRingTone.txt" % (dir_path),"w")
            #     f.write (filePath)
            #     f.close()
            def ClearLog():
                f = open("%sWeekday.txt" % (dir_path),"w")
                f.write("")
                f.close()
                WeekDayUpDateShell.destroy()
                WeekDayUpDate()
            inputtxt = tk.Text(WeekDayUpDateShell,  height = 300, width = 25)
            inputtxt.insert(1.0, 'Type In Your Time One At A Time Like This;\nHr>Min>AM/PM\nEXAMPLE: 03>00>PM\nRESULT: 3:00pm')
            inputtxt.bind("<FocusIn>", lambda args: inputtxt.delete('1.0', 'end'))
            inputtxt.grid(column = 0, row = 1)
            Label (WeekDayUpDateShell, text = "Current Inputted Times;\n HR>MIN>AM/PM;\n-------------------------").place(x = 205, y = 0)
            Label (WeekDayUpDateShell, text = DiffTime).place(x = 230, y = 50)
            Button (WeekDayUpDateShell, text = "Input A Time", command = input).place(x = 205, y = 275)
            Button (WeekDayUpDateShell, text = "Clear All", command = ClearLog).place(x = 285, y = 275)
            # Button (WeekDayUpDateShell, text = "Set up a Ringtone (MP3)", command = SetUp).place(x = 205, y = 248)
            WeekDayUpDateShell.mainloop()

        def FriDayUpDate():
            f = open("%sFriday.txt" % (dir_path),"r")
            DiffTime = f.read()
            f.close()
            WeekDayUpDateShell = Tk()
            window_width = 345
            window_height = 305
            # get the screen dimension
            screen_width = WeekDayUpDateShell.winfo_screenwidth()
            screen_height = WeekDayUpDateShell.winfo_screenheight()
            # find the center point
            center_x = int(screen_width/2 - window_width / 2)
            center_y = int(screen_height/2 - window_height / 2)
            WeekDayUpDateShell.geometry(f'{window_width}x{window_height}+{center_x}+{center_y}')
            def input():
                NewInsert = inputtxt.get("1.0", "end")
                if (NewInsert[0] != "T"):
                    f = open("%sFriday.txt" % (dir_path),"a")
                    f.write(NewInsert)
                    f.close()
                    WeekDayUpDateShell.destroy()
                    WeekDayUpDate()
            def ClearLog():
                f = open("%sFriday.txt" % (dir_path),"w")
                f.write("")
                f.close()
                WeekDayUpDateShell.destroy()
                WeekDayUpDate()
            inputtxt = tk.Text(WeekDayUpDateShell,  height = 300, width = 25)
            inputtxt.insert(1.0, 'Type In Your Time One At A Time Like This;\nHr>Min>AM/PM\nEXAMPLE: 03>00>PM\nRESULT: 3:00pm')
            inputtxt.bind("<FocusIn>", lambda args: inputtxt.delete('1.0', 'end'))
            inputtxt.grid(column = 0, row = 1)
            Label (WeekDayUpDateShell, text = "Current Inputted Times;\n HR>MIN>AM/PM;\n-------------------------").place(x = 205, y = 0)
            Label (WeekDayUpDateShell, text = DiffTime).place(x = 230, y = 50)
            Button (WeekDayUpDateShell, text = "Input A Time", command = input).place(x = 205, y = 275)
            Button (WeekDayUpDateShell, text = "Clear All", command = ClearLog).place(x = 285, y = 275)
            # Button (WeekDayUpDateShell, text = "Set up a Ringtone (MP3)", command = SetUp).place(x = 205, y = 248)
            WeekDayUpDateShell.mainloop()

        # def CheckTimeWeek():
        #     CheckIfRinger()
        #     def Checker():
        #         Timer = time.localtime()
        #         LocalH = Timer[3]
        #         LocalM = Timer[4]
        #         Hours = []
        #         Minutes = []
        #         readTracker = 0
        #         f = open("Weekday.txt","r")
        #         DiffTimes = f.read().split('\n')
        #         for i in DiffTimes:
        #             for j in range(len(i)):
        #                 if (i[j]==">"):
        #                     if (readTracker == 0):
        #                         readTracker+=1
        #                         Hours.append(int(str(i[j-2])+str(i[j-1])))
        #                     elif (readTracker == 1):
        #                         readTracker=0
        #                         Minutes.append(int(str(i[j-2])+str(i[j-1])))
        #         for i in range(len(Hours)):
        #             a=0
        #             for j in DiffTimes:
        #                 for k in j:
        #                     if (k=="P" or k=="p"):
        #                         if (a==0):
        #                             a +=1
        #                             Hours[i]+=12
        #             if(Hours[i]==LocalH and Minutes[i]==LocalM):
        #                 ring()
        #     print("TO KEEP THE ALARM ON: DO NOT CLOSE THIS WINDOW BUT MINIMIZE IT")
        #     print("Created By Aiden Thomas")
        #     while(True):
        #         Checker()
        #         time.sleep(59)

        # def CheckTimeFriday():
        #     CheckIfRinger()
        #     def Checker():
        #         Timer = time.localtime()
        #         LocalH = Timer[3]
        #         LocalM = Timer[4]
        #         Hours = []
        #         Minutes = []
        #         Seconds = []
        #         readTracker = 0
        #         f = open("Friday.txt","r")
        #         DiffTimes = f.read().split('\n')
        #         for i in DiffTimes:
        #             for j in range(len(i)):
        #                 if (i[j]==">"):
        #                     if (readTracker == 0):
        #                         readTracker+=1
        #                         Hours.append(int(str(i[j-2])+str(i[j-1])))
        #                     elif (readTracker == 1):
        #                         readTracker+=1
        #                         Minutes.append(int(str(i[j-2])+str(i[j-1])))
        #                     elif (readTracker == 2):
        #                         readTracker = 0
        #                         Seconds.append(int(str(i[j-2])+str(i[j-1])))
        #         for i in range(len(Hours)):
        #             a=0
        #             for j in DiffTimes:
        #                 for k in j:
        #                     if (k=="P" or k=="p"):
        #                         if (a==0):
        #                             a +=1
        #                             Hours[i]+=12
        #             if(Hours[i]==LocalH and Minutes[i]==LocalM):
        #                 ring()
        #     print("TO KEEP THE ALARM ON: DO NOT CLOSE THIS WINDOW BUT MINIMIZE IT")
        #     print("Created By Aiden Thomas")
        #     while(True):
        #         Checker()
        #         time.sleep(59)


        # def ring():
        #     RingRing = Tk()
        #     window_width = 310
        #     window_height = 70
        #     RingRing.geometry(f'{window_width}x{window_height}+{0}+{0}')
        #     RingRing.attributes("-topmost",1)
        #     Label(RingRing, text= "RING RING\nTIME IS UP").pack()
        #     if (Ringer == True):
        #         Label(RingRing, text ="DO NOT CLOSE THIS WINDOW WHILE MUSIC IS PLAYING\nIT WILL CRASH IF YOU DO!!!").pack()
        #         RingRing.after(150, lambda: winsound.PlaySound("DopeRinger.wav", winsound.SND_FILENAME))
        #         RingRing.after(30160, lambda: RingRing.destroy())
        #     RingRing.mainloop()
            

        # def CheckIfRinger():
        #     RingRing = Tk()
        #     window_width = 300
        #     window_height = 70
        #     RingRing.geometry(f'{window_width}x{window_height}+{0}+{0}')
        #     RingRing.attributes("-topmost",1)
        #     def yes():
        #         global Ringer
        #         Ringer = True
        #         RingRing.destroy()
        #     def no():
        #         global Ringer
        #         Ringer = False
        #         RingRing.destroy()
        #     Label(RingRing, text= "Would you like sound?\nWarning: increases the chance of crashing").grid(row = 0, column = 1)
        #     Button(RingRing, text= "yes", command = yes).grid(row = 1, column = 2)
        #     Button(RingRing, text= "no", command = no).grid(row = 1, column = 3)
        #     RingRing.mainloop()

        def StartClock():
            File = open("%sBaseFile.txt" % (dir_path),"r")
            BaseFile = File.read()
            File.close()
            if (int(BaseFile)):
                os.startfile(dir_path+"AppData\\Roaming\\Microsoft\\Windows\\Start Menu\\Programs\\Startup\\TimerCirlc.exe")
            else:
                os.startfile("%sTimerCirlc.exe" % (dir_path))

        def main(dir_path):
            global Ringing
            Ringme = open("%sRinger.txt" % (dir_path), "r")
            Ringing = Ringme.read()
            Ringme.close()
            mainmenu = Tk()
            window_width = 327
            window_height = 77
            # get the screen dimension
            screen_width = mainmenu.winfo_screenwidth()
            screen_height = mainmenu.winfo_screenheight()
            # find the center point
            center_x = int(screen_width/2 - window_width / 2)
            center_y = int(screen_height/2 - window_height / 2)
            mainmenu.geometry(f'{window_width}x{window_height}+{center_x}+{center_y}')


            def FriUpdate():
                FriDayUpDate()

            def WeekUpdate():
                WeekDayUpDate()

            def WeekRun():
                mainmenu.destroy()
                StartClock()
            def selection():
                global Ringing
                print(Ringing)
                if (Ringing=="True"):
                    Ringing = "False"
                else:
                    Ringing = "True"
                mainmenu.destroy()
                Ring = open("%sRinger.txt" % (dir_path), "w")
                Ring.write(Ringing)
                Ring.close()
                main(dir_path)
            def mWAV():
                os.replace(filedialog.askopenfilename(), "%sDopeRinger.wav" % (dir_path))
            Button(mainmenu, text = "Update Your Weekday Clock", command = WeekUpdate, width = 22).grid(column=1,row=0)
            Button(mainmenu, text = "Update Your Friday Clock", command = FriUpdate, width = 22).grid(column=2,row=0)
            if (Ringing=="True"):
                Button(mainmenu, text='No Sound?', command=selection, width = 22).grid(column=2,row=1)
            else:
                Button(mainmenu, text='Sound?', command=selection, width = 22).grid(column=2,row=1)
            Button(mainmenu, text = "Start Your Runtime Clock", command = WeekRun, width = 22).grid(column=1,row=2)
            Button(mainmenu, text = "insert a .wav file (sound)",command= mWAV, width= 22).grid(column= 1, row=1)
            
            mainmenu.mainloop()

        main(dir_path)

if __name__ == '__main__':
    dir_path = os.path.dirname(os.path.realpath(__file__))
    print(dir_path)
    dir_path = dir_path.split("\\")
    dir_path = dir_path[0]+"\\"+dir_path[1]+"\\"+dir_path[2]+"\\"
    print(dir_path)
    smain(dir_path)









