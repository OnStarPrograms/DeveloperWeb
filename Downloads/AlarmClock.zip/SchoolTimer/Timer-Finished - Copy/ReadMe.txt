Just Like Before, Not really extensively tested, everything should be a ok.
just run the setup first and then the Timer.exe will move to the desktop.

DELETE THE SETUP.EXE AS SOON AS IT IS DONE!!!

You only need to run the Timer.exe after you have run setup :)

Any Problems, Email my email-robot at player1.123456788@gmail.com 