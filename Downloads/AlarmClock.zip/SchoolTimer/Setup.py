import os 
from tkinter import *
dir_path = os.path.dirname(os.path.realpath(__file__))
print(dir_path)
dir_path = dir_path.split("\\")
dir_path = dir_path[0]+"\\"+dir_path[1]+"\\"+dir_path[2]+"\\"
print(dir_path)
try:
            f = open ("%sWeekday.txt" % (dir_path),"x")
            f.close()
except:
            print("Yay! no setup!")
try:
            f = open ("%sFriday.txt" % (dir_path),"x")
            f.close()
except:
            print("Yay! no setup!")
Autumn = 0
MyShell = Tk()
def AutoStart():
    global Autumn
    Autumn = 1
    os.replace("TimerCirlc.exe", "%sTimerCirlc.exe" % (dir_path+"AppData\\Roaming\\Microsoft\\Windows\\Start Menu\\Programs\\Startup\\"))
    MyShell.destroy()
def NoAutoStart():
    MyShell.destroy()
Button(MyShell,text = "Add Automatic Startup?", command = AutoStart).grid(column=1,row=0)
Button(MyShell,text = "Don't Add Automatic Startup", command = NoAutoStart).grid(column=1,row=1)
Label(MyShell, text = "You will have to redownload this [entire] project to\n reactivate/deactivate Startup").grid(column=1,row=2)
MyShell.mainloop()
if (not Autumn):
    os.replace("TimerCirlc.exe", "%sTimerCirlc.exe" % (dir_path))
File = open("%sBaseFile.txt" % (dir_path),"w")
File.write(str(Autumn))
File.close()
os.replace("Timer.exe", "%sTimer.exe" % (dir_path+"Desktop\\"))
os.replace("DopeRinger.wav", "%sDopeRinger.wav" % (dir_path))
# try:
#             f = open ("%sRingTone.txt" % (dir_path),"x")
#             f.close()
# except:
#             print("Yay! no setup!")
