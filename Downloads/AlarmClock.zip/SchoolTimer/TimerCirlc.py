from tkinter import *
import winsound
import time
import datetime
import os

def CheckTimeWeek(dir_path):
            def Checker():
                Timer = time.localtime()
                LocalH = Timer[3]
                LocalM = Timer[4]
                Hours = []
                Minutes = []
                readTracker = 0
                f = open("%sWeekday.txt" % (dir_path),"r")
                DiffTimes = f.read().split('\n')
                for i in DiffTimes:
                    for j in range(len(i)):
                        if (i[j]==":" or i[j]=="p" or i[j]=="P"):
                            if (readTracker == 0):
                                readTracker+=1
                                Hours.append(int(str(i[j-2])+str(i[j-1])))
                            elif (readTracker == 1):
                                readTracker=0
                                Minutes.append(int(str(i[j-2])+str(i[j-1])))
                for i in range(len(Hours)):
                    a=0
                    for j in DiffTimes:
                        for k in j:
                            if ((k=="P" or k=="p") and (j[0] != "1" and j[1] != "2")):
                                if (a==0):
                                    a +=1
                                    Hours[i]+=12
                    if(Hours[i]==LocalH and Minutes[i]==LocalM):
                        ring(dir_path)
            print("Created By Aiden Thomas")
            while(True):
                Checker()
                time.sleep(59)

def CheckTimeFriday(dir_path):
            def Checker():
                Timer = time.localtime()
                LocalH = Timer[3]
                LocalM = Timer[4]
                Hours = []
                Minutes = []
                Seconds = []
                readTracker = 0
                f = open("%sFriday.txt" % (dir_path),"r")
                DiffTimes = f.read().split('\n')
                for i in DiffTimes:
                    for j in range(len(i)):
                        if (i[j]==":" or i[j]=="p" or i[j]=="P"):
                            if (readTracker == 0):
                                readTracker+=1
                                Hours.append(int(str(i[j-2])+str(i[j-1])))
                            elif (readTracker == 1):
                                readTracker+=1
                                Minutes.append(int(str(i[j-2])+str(i[j-1])))
                            elif (readTracker == 2):
                                readTracker = 0
                                Seconds.append(int(str(i[j-2])+str(i[j-1])))
                for i in range(len(Hours)):
                    a=0
                    for j in DiffTimes:
                        for k in j:
                            if ((k=="P" or k=="p") and (j[0] != "1" and j[1] != "2")):
                                if (a==0):
                                    a +=1
                                    Hours[i]+=12
                    if(Hours[i]==LocalH and Minutes[i]==LocalM):
                        ring(dir_path)
            print("Created By Aiden Thomas")
            while(True):
                Checker()
                time.sleep(59)


def ring(dir_path):
            Ring = open("%sRinger.txt" % (dir_path), "r")
            Ringer = Ring.read()
            Ring.close()
            RingRing = Tk()
            window_width = 310
            window_height = 70
            RingRing.geometry(f'{window_width}x{window_height}+{0}+{0}')
            RingRing.attributes("-topmost",1)
            Label(RingRing, text= "RING RING\nTIME IS UP").pack()
            if (Ringer == "True"):
                Label(RingRing, text ="DO NOT CLOSE THIS WINDOW WHILE MUSIC IS PLAYING\nIT WILL CRASH IF YOU DO!!!").pack()
                RingRing.after(150, lambda: winsound.PlaySound("%sDopeRinger.wav" % (dir_path), winsound.SND_FILENAME))
                RingRing.after(30160, lambda: RingRing.destroy())
            RingRing.mainloop()
            

if __name__ == '__main__':
    Day = datetime.datetime.today().weekday()
    dir_path = os.path.dirname(os.path.realpath(__file__))
    print(dir_path)
    dir_path = dir_path.split("\\")
    dir_path = dir_path[0]+"\\"+dir_path[1]+"\\"+dir_path[2]+"\\"
    if (Day == 4):
        print("Friday")
        CheckTimeFriday(dir_path)
    else:
        print("Week")
        CheckTimeWeek(dir_path)