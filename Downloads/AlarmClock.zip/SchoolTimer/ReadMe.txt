You can have diff ringtones... only caviat is that it has to be in the same
file directory as the .exe file AND be named "DopeRinger" as well as being in 
.wav form

the only way errors can occur is via wrong time inputs, closing widgets when
it says "DO NOT CLOSE", and wrong audio files. check these simple occurances when
an error occurs first and FOREMOST.

common error symptoms:
1. the command shell closes itself
2. the command shell doesnt say, "created by Aiden Thomas" when you start the timer
3. the windows "ding" sound occurs instead of your loaded music
4. you get the spinning wheel of death when you close a widget

Created by,
Aiden Thomas

