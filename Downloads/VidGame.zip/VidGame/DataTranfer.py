import ezgmail
import os

def Switch(Snum):
    match Snum:
        case 1:
            Mail1()

def Mail1():
    print("Where switch send p1")

if __name__ == '__main__':
    ezgmail.send('aidenthomas711@gmail.com', 'Player One says Hi!', 'Hi!')
