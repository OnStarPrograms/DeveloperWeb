from tkinter import *
root = Tk()
Label(root, text="AAAAAAAAAAAAAAAAAAAA\nAAAAAAAA                AAAAAA\nAAAAAAA                   AAAAAA\nAAAAAA         A          AAAAAA\nAAAAA         AA          AAAAAA\nAAAA         AAA          AAAAAA\nAAA         AAAA          AAAAAA\nAA         AAAAA          AAAAAA\n                                         AAAAA\nA       AAAAAAA          AAAAAA").pack()

root.mainloop()
 
