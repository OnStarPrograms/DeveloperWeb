from tkinter import *


a = Tk()
a.attributes("-topmost", 1)
Label(a, text = "Your not supposed to see this", fg="#1F51FF",  bg = "black").pack()
a.mainloop()