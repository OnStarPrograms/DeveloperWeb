—--- \ / 1== 1 \ / == \ \\ /// 11 \ -===11111==111 /111 101 01
I | \ \ | ( / /\_\|F/ \ \ \V/ |F/ \\ 10| | | || 11 1101 01
I | ) }| =1=| ( _ |0\_ /_/ 1| 1 \_ 1/ | 1 |01 || 11 11101 11
I | / / |0( \ \/ /| |\01 || |01 |01 101 11 11 11 10111
—--- / \ === \_ / |_| 10\ |1 101 101 11111 1111 11 1001
(decryption)

Game design by: Karol, Aiden, Tristan
Base Program (Back end): Aiden
User Interface (Front End): Karol & Tristan
Artwork (Artist): Jacob

Created for Technology Student Association 2024

Rough Playtime estimate (4 Players: 5 Min)

Games' .exe file is meant to be run multiple times throughout the gameplay.

Game can play with upto Five Players

Game should not require Administrative Access to run

Signed;

Aiden Thomas 
TSA Satellite HS President